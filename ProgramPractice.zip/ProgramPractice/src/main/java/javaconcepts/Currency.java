package javaconcepts;

public enum Currency{

    PENNY,NICKEL,DIME,QUATER;

}