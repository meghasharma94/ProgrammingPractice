package javaconcepts;

public class RunTimePolymorphism {
}
