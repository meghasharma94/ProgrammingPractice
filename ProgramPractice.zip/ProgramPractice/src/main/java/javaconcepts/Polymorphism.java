package javaconcepts;

public class Polymorphism {



    protected static int  add(int a , int b) throws Exception{


        System.out.println(a+b);
        return a+b;
    }

    public void add(int a ,int b,int c){

        System.out.println(a+b+c);

    }



    public static void main(String[] args) throws Exception{

        Polymorphism p=new Polymorphism();
        p.add(5,10);


    }

}
