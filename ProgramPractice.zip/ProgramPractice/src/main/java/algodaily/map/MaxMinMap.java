package algodaily.map;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MaxMinMap {


    public static void findMaxProfit(Map<String,Integer> widgets){

        System.out.println("Map" +widgets);

        Integer A= Collections.min(widgets.values());
        Integer B= Collections.max(widgets.values());

        System.out.println("Minimum Key of Map is: "
                + A +":" + B);

        String maxKey=null,minKey=null;

        for (Map.Entry<String, Integer> entry : widgets.entrySet()) {
            if (entry.getValue()==A) {
                minKey=entry.getKey();     // Print the key with min value
            }
            if (entry.getValue()==B) {
                maxKey=entry.getKey();     // Print the key with max value
            }
        }

        System.out.println("Minimum Key of Map is: "
                + minKey);
        System.out.println("Value corresponding to "
                + "minimum Key of Map is: "
                + widgets.get(minKey));

        // printing the maximum value
        System.out.println("Maximum Key of Map is: " + maxKey);
        System.out.println("Value corresponding to "
                + "maximum Key of Map is: "
                + widgets.get(maxKey));

        System.out.println("The max difference is:  " + (widgets.get(maxKey)-widgets.get(minKey)));

        //JAVA8

        String max=widgets.entrySet().stream().max((entry1 ,entry2)-> entry1.getValue()> entry2.getValue() ? 1:-1).get().getKey();
        String x=widgets.entrySet().stream().min(Map.Entry.comparingByValue()).get().getKey();
        System.out.println("max in java 8"+ max +":"+x);

   }

    public static void main(String[] args){


        Map<String,Integer> widgets=new HashMap<String,Integer>();

        widgets.put("London",72);
        widgets.put("New York",70);
        widgets.put("Tokyo",67);
        widgets.put("Miami",62);


        findMaxProfit(widgets);


    }






}
