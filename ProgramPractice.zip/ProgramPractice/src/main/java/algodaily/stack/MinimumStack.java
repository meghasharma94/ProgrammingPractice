package algodaily.stack;

import java.util.Scanner;

public class MinimumStack {

        private int size,topIndex,min;
        private int[] stack;


        public MinimumStack(int size) {

              this.stack=new int[size];
              this.size=size;
              this.topIndex=0;

        }

        public boolean isEmpty(){

            if(topIndex==0){

                return true;
            }

            return false;
        }

        public boolean isFull(){

            if(topIndex -1 == size){

                return true;
            }
            return false;
        }

        public void push(int val) {
            if(isFull()){

                throw new RuntimeException("the stack is has reached it full capacity");
            }

            if(topIndex==0){

                min=val;
            }

            stack[topIndex]=val;
            topIndex++;

             min=(min<val)?min:val;

        }

        public int pop() {

            if(isEmpty()){

                throw new RuntimeException("the stack is empty");
             }
            return stack[--topIndex];
        }

        public int peek() {
            if(!isEmpty()){

                return stack[topIndex];
            }

            System.out.println("Stack is Empty");
            return -1;

        }

        public int min() {

            return min;
        }


    // remove or comment if running tests (we run our own main)
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);

        System.out.println("Please enter the size of stack");
        int size= scan.nextInt();
        MinimumStack minStack=new MinimumStack(size);

        for(int i=0;i<size;i++){

            System.out.println("Please enter the value of :"+i + "th index in stack");

            int val=scan.nextInt();
            minStack.push(val);

        }

        System.out.println("The minimum value in the stack is "+ minStack.min());

     }



}
