package algodaily.medium;

import java.util.LinkedHashMap;
import java.util.Map;

public class LeastRecentlyUsed {

    private LinkedHashMap<Integer,Integer> map;


    public LeastRecentlyUsed(int capacity){


        map=new LinkedHashMap<>(capacity, .75f,true){

        protected boolean removeEldestEntry(Map.Entry eldest){

            return size()>capacity;
        } };
    }


    public int get(int key){

        return map.getOrDefault(key,-1);

    }

    public void set(int key, int value){

        map.put(key,value);
    }




    public static void main(String[] args){

        LeastRecentlyUsed lru=new LeastRecentlyUsed(3);
        lru.set(1,30);
        lru.set(2,20);

        System.out.println("Value for the key: 1 is " +
                lru.get(1));

        lru.set(3,40);
        lru.set(4,60);

        System.out.println("Value for the key: 2 is " +
                lru.get(2));
        lru.set(1,30);

        System.out.println(lru);
    }


}
