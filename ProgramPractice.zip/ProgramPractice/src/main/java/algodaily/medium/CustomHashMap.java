package algodaily.medium;

import java.util.HashMap;

public class CustomHashMap {


//    public static Node<K,V>{
//        final k key;
//        V value;
//        final int hash;
//        Node<K,V> node;
//
//        public Node
//
//    }





}
